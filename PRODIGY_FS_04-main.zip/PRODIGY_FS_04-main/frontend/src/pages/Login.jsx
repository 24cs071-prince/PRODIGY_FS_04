import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Mail, Lock, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

// Custom Syncora Branding Logo
const SyncoraLogo = ({ className = "w-10 h-10" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Outer orbit path */}
    <ellipse cx="50" cy="50" rx="38" ry="14" transform="rotate(-30 50 50)" className="stroke-indigo-500/30" strokeWidth="1.5" strokeDasharray="4 4" />
    <ellipse cx="50" cy="50" rx="38" ry="14" transform="rotate(45 50 50)" className="stroke-purple-500/40" strokeWidth="1.5" />
    
    {/* Neon orbits */}
    <ellipse cx="50" cy="50" rx="28" ry="10" transform="rotate(15 50 50)" className="stroke-indigo-400" strokeWidth="2.5" />
    <ellipse cx="50" cy="50" rx="28" ry="10" transform="rotate(-60 50 50)" className="stroke-purple-400" strokeWidth="2" />
    
    {/* Inner glowing core */}
    <circle cx="50" cy="50" r="12" className="fill-indigo-600/30 stroke-indigo-400" strokeWidth="2" />
    <circle cx="50" cy="50" r="5" className="fill-indigo-300 shadow-[0_0_10px_#818cf8]" />
    
    {/* Orbiting node details */}
    <circle cx="75" cy="43" r="3.5" className="fill-indigo-300 animate-pulse" />
    <circle cx="25" cy="57" r="2.5" className="fill-purple-300" />
  </svg>
);

// Simulated QR code component with custom Syncora branding in the center
const QRContainer = () => {
  return (
    <div className="relative p-3 bg-white rounded-2xl shadow-2xl flex items-center justify-center w-[180px] h-[180px] group transition-all duration-300 hover:shadow-indigo-500/10 border border-white/20">
      {/* Standard QR Code representation using SVGs */}
      <svg className="w-full h-full text-[#111319]" viewBox="0 0 100 100" fill="currentColor">
        {/* Top Left Finder Pattern */}
        <path d="M 0 0 L 25 0 L 25 25 L 0 25 Z M 5 5 L 5 20 L 20 20 L 20 5 Z M 9 9 L 16 9 L 16 16 L 9 16 Z" />
        {/* Top Right Finder Pattern */}
        <path d="M 75 0 L 100 0 L 100 25 L 75 25 Z M 80 5 L 80 20 L 95 20 L 95 5 Z M 84 9 L 91 9 L 91 16 L 84 16 Z" />
        {/* Bottom Left Finder Pattern */}
        <path d="M 0 75 L 25 75 L 25 100 L 0 100 Z M 5 80 L 5 95 L 20 95 L 20 80 Z M 9 84 L 16 84 L 16 91 L 9 91 Z" />
        {/* Bottom Right Alignment block */}
        <path d="M 82 82 L 88 82 L 88 88 L 82 88 Z" />
        
        {/* QR Code pseudo-random code blocks */}
        <path d="M 35 5 H 40 V 10 H 35 Z M 45 5 H 55 V 15 H 45 Z M 60 5 H 65 V 10 H 60 Z M 65 15 H 70 V 20 H 65 Z" />
        <path d="M 5 35 H 15 V 40 H 5 Z M 20 30 H 25 V 45 H 20 Z M 30 30 H 45 V 35 H 30 Z M 40 40 H 45 V 45 H 40 Z" />
        <path d="M 50 30 H 60 V 35 H 50 Z M 65 30 H 70 V 35 H 65 Z M 55 40 H 60 V 50 H 55 Z M 70 45 H 85 V 50 H 70 Z" />
        <path d="M 80 30 H 90 V 35 H 80 Z M 85 40 H 95 V 45 H 85 Z M 90 55 H 100 V 60 H 90 Z" />
        <path d="M 30 50 H 35 V 60 H 30 Z M 40 55 H 45 V 65 H 40 Z M 10 65 H 15 V 70 H 10 Z M 20 60 H 25 V 70 H 20 Z" />
        <path d="M 35 70 H 40 V 85 H 35 Z M 45 75 H 55 V 80 H 45 Z M 50 85 H 65 V 90 H 50 Z M 60 70 H 70 V 75 H 60 Z" />
        <path d="M 70 60 H 75 V 70 H 70 Z M 80 65 H 85 V 75 H 80 Z M 75 80 H 80 V 90 H 75 Z M 90 75 H 95 V 95 H 90 Z" />
      </svg>
      
      {/* Central Syncora Brand Badge in the QR */}
      <div className="absolute inset-0 m-auto w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg border border-gray-100">
        <SyncoraLogo className="w-8 h-8" />
      </div>

      {/* Laser Scanner Line Effect */}
      <motion.div 
        animate={{ y: [0, 150, 0] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
        className="absolute left-0 top-3 w-full h-[3px] bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_2px_rgba(52,211,153,0.8)]"
      />
    </div>
  );
};

// Twinkling Star background component for cosmic effect
const CosmicBackground = () => {
  // Coordinates and attributes of starry field to minimize runtime compute
  const stars = [
    { top: '10%', left: '5%', size: 2, delay: 0.2, duration: 4 },
    { top: '15%', left: '85%', size: 3, delay: 1.2, duration: 5 },
    { top: '25%', left: '45%', size: 1.5, delay: 0.5, duration: 3 },
    { top: '40%', left: '15%', size: 2.5, delay: 2.1, duration: 4.5 },
    { top: '55%', left: '80%', size: 2, delay: 0.8, duration: 3.5 },
    { top: '65%', left: '35%', size: 3, delay: 1.7, duration: 6 },
    { top: '75%', left: '90%', size: 1.5, delay: 0.3, duration: 4 },
    { top: '85%', left: '20%', size: 2, delay: 2.5, duration: 5.5 },
    { top: '92%', left: '60%', size: 2.5, delay: 1.5, duration: 3.8 },
    { top: '8%', left: '30%', size: 1.5, delay: 0.7, duration: 4.2 },
    { top: '33%', left: '72%', size: 2, delay: 1.9, duration: 5.1 },
    { top: '48%', left: '95%', size: 2.5, delay: 0.4, duration: 3.6 },
    { top: '60%', left: '8%', size: 1.5, delay: 1.1, duration: 4.9 },
    { top: '78%', left: '50%', size: 3, delay: 2.8, duration: 6.2 },
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Stars Layer */}
      {stars.map((star, idx) => (
        <motion.div
          key={idx}
          initial={{ opacity: 0.1, scale: 0.8 }}
          animate={{ opacity: [0.1, 1, 0.1], scale: [0.8, 1.2, 0.8] }}
          transition={{ duration: star.duration, repeat: Infinity, delay: star.delay, ease: "easeInOut" }}
          className="absolute bg-white rounded-full shadow-[0_0_8px_1px_rgba(255,255,255,0.7)]"
          style={{ width: star.size, height: star.size, top: star.top, left: star.left }}
        />
      ))}
      
      {/* Nebulae / Glow Circles */}
      <div className="absolute -top-[30%] -left-[10%] w-[60%] h-[60%] rounded-full bg-indigo-900/20 blur-[130px] animate-pulse" style={{ animationDuration: '8s' }} />
      <div className="absolute -bottom-[30%] -right-[10%] w-[60%] h-[60%] rounded-full bg-purple-900/20 blur-[130px] animate-pulse" style={{ animationDuration: '10s', animationDelay: '2s' }} />
      <div className="absolute top-[35%] left-[40%] w-[350px] h-[350px] rounded-full bg-blue-900/10 blur-[100px] pointer-events-none" />
    </div>
  );
};

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#07080e] via-[#0d0e1b] to-[#16142e] flex items-center justify-center p-4 relative font-sans overflow-x-hidden">
      {/* Cosmic background effects */}
      <CosmicBackground />

      {/* Syncora Logo Top Left Header */}
      <div className="absolute top-6 left-6 z-20 flex items-center space-x-3">
        <SyncoraLogo className="w-9 h-9" />
        <span className="text-white font-bold text-2xl tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-200 to-indigo-400">
          Syncora
        </span>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="w-full max-w-4xl relative z-10 mx-auto"
      >
        {/* Core Glassmorphic Container */}
        <div className="bg-[#151722]/55 backdrop-blur-2xl rounded-3xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] border border-white/[0.08] overflow-hidden flex flex-col md:flex-row">
          
          {/* Left Pane - Form Entry */}
          <div className="flex-1 p-8 md:p-12 flex flex-col justify-center">
            <div className="mb-8">
              <h2 className="text-3xl font-extrabold text-white mb-2.5 tracking-tight">Welcome back!</h2>
              <p className="text-gray-400 text-sm md:text-base">We are so excited to see you again!</p>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm text-center font-medium shadow-sm"
              >
                {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-2.5">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-500 group-focus-within:text-indigo-400 transition-colors duration-200" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full pl-12 pr-4 py-3.5 bg-[#090b10]/80 border border-white/10 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/80 transition-all duration-200 text-[15px]"
                    placeholder="name@domain.com"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2.5">
                  <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                    Password <span className="text-rose-500">*</span>
                  </label>
                  <a href="#forgot" className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
                    Forgot your password?
                  </a>
                </div>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-500 group-focus-within:text-indigo-400 transition-colors duration-200" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="block w-full pl-12 pr-4 py-3.5 bg-[#090b10]/80 border border-white/10 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/80 transition-all duration-200 text-[15px]"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center items-center py-4 px-4 border border-transparent rounded-2xl shadow-xl text-base font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#151722] focus:ring-indigo-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 cursor-pointer shadow-indigo-600/10 hover:shadow-indigo-500/20 active:translate-y-0"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Log In'
                )}
              </button>
            </form>

            <p className="mt-8 text-center text-sm text-gray-400">
              Need an account?{' '}
              <Link to="/register" className="font-bold text-indigo-400 hover:text-indigo-300 hover:underline transition-all">
                Register
              </Link>
            </p>
          </div>
          
          {/* Right Pane - Simulated QR Scanner Portal (Matches Discord Aesthetic) */}
          <div className="hidden md:flex w-[350px] bg-[#0c0d15]/85 p-12 flex-col items-center justify-center border-l border-white/[0.05] relative overflow-hidden">
            {/* Soft decorative neon glow behind QR */}
            <div className="absolute w-[200px] h-[200px] rounded-full bg-indigo-500/5 blur-[50px] pointer-events-none" />
            
            <QRContainer />
            
            <div className="text-center mt-8 relative z-10">
              <h3 className="text-white text-xl font-bold mb-2">Log in with QR Code</h3>
              <p className="text-gray-400 text-xs leading-relaxed max-w-[240px] mx-auto">
                Scan this with the <strong>Syncora mobile app</strong> to log in instantly.
              </p>
              
              <div className="mt-6">
                <a href="#passkey" className="text-indigo-400 hover:text-indigo-300 text-xs font-bold transition-all hover:underline">
                  Or, sign in with passkey
                </a>
              </div>
            </div>
          </div>

        </div>
      </motion.div>
    </div>
  );
};

export default Login;
