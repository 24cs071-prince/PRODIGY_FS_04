import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import axios from 'axios';
import { motion } from 'framer-motion';
import { 
  MessageSquare, LogOut, Send, User, Hash, Plus, Users, Bell, 
  Paperclip, Loader2, MoreHorizontal, Pencil, X, Settings, 
  Check, UserPlus, Image as ImageIcon, Compass, Shield, ShieldAlert,
  Search, CornerUpLeft, Smile
} from 'lucide-react';

const NOTIFICATION_SOUND = 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3';

const SyncoraLogo = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="50" rx="38" ry="14" transform="rotate(-30 50 50)" className="stroke-indigo-400/50" strokeWidth="2.5" />
    <ellipse cx="50" cy="50" rx="28" ry="10" transform="rotate(15 50 50)" className="stroke-purple-400" strokeWidth="3.5" />
    <circle cx="50" cy="50" r="10" className="fill-indigo-500/30 stroke-indigo-300" strokeWidth="2" />
    <circle cx="50" cy="50" r="4" className="fill-white animate-pulse" />
  </svg>
);

// Twinkling Star background component for cosmic effect
const CosmicBackground = () => {
  const stars = [
    { top: '5%', left: '10%', size: 2, delay: 0.1, duration: 4 },
    { top: '12%', left: '88%', size: 2.5, delay: 1.2, duration: 5.5 },
    { top: '22%', left: '42%', size: 1.5, delay: 0.3, duration: 3.2 },
    { top: '35%', left: '18%', size: 3, delay: 2.2, duration: 4.8 },
    { top: '48%', left: '85%', size: 2, delay: 0.7, duration: 3.5 },
    { top: '65%', left: '38%', size: 2.5, delay: 1.8, duration: 6 },
    { top: '75%', left: '92%', size: 1.5, delay: 0.4, duration: 4.1 },
    { top: '88%', left: '15%', size: 2, delay: 2.4, duration: 5.2 },
    { top: '94%', left: '55%', size: 3, delay: 1.4, duration: 3.7 },
    { top: '28%', left: '74%', size: 1.5, delay: 0.9, duration: 4.5 },
    { top: '52%', left: '94%', size: 2.5, delay: 0.5, duration: 3.4 },
    { top: '68%', left: '8%', size: 1.5, delay: 1.3, duration: 4.7 },
    { top: '82%', left: '48%', size: 3, delay: 2.6, duration: 6.2 },
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {stars.map((star, idx) => (
        <motion.div
          key={idx}
          initial={{ opacity: 0.1, scale: 0.8 }}
          animate={{ opacity: [0.1, 1, 0.1], scale: [0.8, 1.2, 0.8] }}
          transition={{ duration: star.duration, repeat: Infinity, delay: star.delay, ease: "easeInOut" }}
          className="absolute bg-white rounded-full shadow-[0_0_8px_1px_rgba(255,255,255,0.7)]"
          style={{ width: star.size, height: star.size, top: star.top, left: star.left }}
        />
      ))}
      <div className="absolute top-[20%] left-[25%] w-[400px] h-[400px] rounded-full bg-indigo-500/5 blur-[120px]" />
      <div className="absolute bottom-[20%] right-[25%] w-[400px] h-[400px] rounded-full bg-purple-500/5 blur-[120px]" />
    </div>
  );
};

const ChatApp = () => {
  const { user, logout } = useAuth();
  const socket = useSocket();
  
  const [friends, setFriends] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [servers, setServers] = useState([]);
  const [channels, setChannels] = useState([]);
  
  const [activeServer, setActiveServer] = useState(null);
  const [activeChat, setActiveChat] = useState(null);
  const [chatType, setChatType] = useState(null);
  
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [currentId, setCurrentId] = useState(null);

  const [showSettings, setShowSettings] = useState(false);
  const [showCreateServer, setShowCreateServer] = useState(false);
  const [newServerName, setNewServerName] = useState('');
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [newChannelName, setNewChannelName] = useState('');
  const [showJoinServer, setShowJoinServer] = useState(false);
  const [joinInviteCode, setJoinInviteCode] = useState('');
  const [addFriendInput, setAddFriendInput] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [bioInput, setBioInput] = useState(user?.bio || '');
  const [friendsTab, setFriendsTab] = useState('online');

  // Phase 9: Server Settings State
  const [showServerSettings, setShowServerSettings] = useState(false);
  const [serverSettingsTab, setServerSettingsTab] = useState('roles');
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleColor, setNewRoleColor] = useState('#6366f1');
  const [newRolePerms, setNewRolePerms] = useState({
    MANAGE_SERVER: false, MANAGE_CHANNELS: false, MANAGE_ROLES: false, KICK_MEMBERS: false
  });

  // Phase 10: Rich Interactions & Global Search State
  const [replyingToMessage, setReplyingToMessage] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [messageSearchResults, setMessageSearchResults] = useState([]);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [hoveredMessageId, setHoveredMessageId] = useState(null);

  const [typingUsers, setTypingUsers] = useState({});
  const [unreadCounts, setUnreadCounts] = useState({});
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeMenu, setActiveMenu] = useState(null);
  const [editingMessage, setEditingMessage] = useState(null);
  const [uploading, setUploading] = useState(false);
  
  const fileInputRef = useRef(null);
  const avatarInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const audioRef = useRef(new Audio(NOTIFICATION_SOUND));

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(() => scrollToBottom(), [messages, typingUsers]);

  const fetchData = async () => {
    try {
      const [friendsRes, reqsRes, serversRes] = await Promise.all([
        axios.get('/friends'), axios.get('/friends/requests'), axios.get('/servers')
      ]);
      setFriends(friendsRes.data);
      setPendingRequests(reqsRes.data);
      setServers(serversRes.data);
    } catch (error) { console.error('Error fetching data', error); }
  };

  useEffect(() => { fetchData(); }, []);

  useEffect(() => {
    if (activeServer) {
      axios.get(`/servers/${activeServer._id}/channels`)
        .then(res => {
          setChannels(res.data);
          if (res.data.length > 0) joinChannel(res.data[0]);
        }).catch(err => console.error(err));
    }
  }, [activeServer]);

  useEffect(() => {
    if (!socket) return;
    const handleReceiveMessage = (message) => {
      if (message.conversationId === currentId || message.roomId === currentId) {
        setMessages((prev) => [...prev, message]);
        if (message.sender !== user._id && message.sender?._id !== user._id) audioRef.current.play().catch(()=>null);
      } else {
        const sourceId = message.roomId || message.sender._id || message.sender;
        setUnreadCounts(prev => ({ ...prev, [sourceId]: (prev[sourceId] || 0) + 1 }));
        setNotifications(prev => [{...message, notifId: Date.now()}, ...prev].slice(0, 20));
        audioRef.current.play().catch(()=>null);
      }
    };
    const handleUserStatus = ({ userId, status, lastSeen }) => {
      setFriends(prev => prev.map(u => u._id === userId ? { ...u, status, lastSeen } : u));
      if (activeChat && activeChat._id === userId) setActiveChat(prev => ({ ...prev, status, lastSeen }));
    };
    const handleTyping = ({ conversationId, userId }) => {
      if (conversationId === currentId && userId !== user._id) {
        const typingUser = friends.find(u => u._id === userId) || activeChat;
        setTypingUsers(prev => ({ ...prev, [userId]: typingUser?.username || 'Someone' }));
      }
    };
    const handleStopTyping = ({ conversationId, userId }) => {
      if (conversationId === currentId) setTypingUsers(prev => { const newState = { ...prev }; delete newState[userId]; return newState; });
    };
    const handleMessageDeleted = (id) => setMessages((prev) => prev.filter((m) => m._id !== id));
    const handleMessageEdited = (msg) => setMessages((prev) => prev.map((m) => m._id === msg._id ? msg : m));
    const handleReactionUpdated = ({ messageId, updatedMessage }) => {
      setMessages((prev) => prev.map((m) => m._id === messageId ? updatedMessage : m));
    };

    socket.on('receive_message', handleReceiveMessage);
    socket.on('user_status_change', handleUserStatus);
    socket.on('typing', handleTyping);
    socket.on('stop_typing', handleStopTyping);
    socket.on('message_deleted', handleMessageDeleted);
    socket.on('message_edited', handleMessageEdited);
    socket.on('reaction_updated', handleReactionUpdated);

    return () => {
      socket.off('receive_message', handleReceiveMessage);
      socket.off('user_status_change', handleUserStatus);
      socket.off('typing', handleTyping);
      socket.off('stop_typing', handleStopTyping);
      socket.off('message_deleted', handleMessageDeleted);
      socket.off('message_edited', handleMessageEdited);
      socket.off('reaction_updated', handleReactionUpdated);
    };
  }, [socket, currentId, activeChat, friends, user._id]);

  const clearUnread = (id) => {
    setUnreadCounts(prev => { const newState = { ...prev }; delete newState[id]; return newState; });
    setNotifications(prev => prev.filter(n => (n.roomId !== id && n.sender !== id && n.sender?._id !== id)));
  };

  const startDM = async (targetUser) => {
    setActiveChat(targetUser); setChatType('dm'); clearUnread(targetUser._id);
    try {
      const res = await axios.post('/chat/messages', { receiverId: targetUser._id, text: 'Started a conversation', type: 'text' });
      const convId = res.data.conversationId;
      setCurrentId(convId);
      if (socket) socket.emit('join_chat', convId);
      const historyRes = await axios.get(`/chat/messages/${convId}`);
      setMessages(historyRes.data);
    } catch (error) { console.error('Error starting DM', error); }
  };

  const joinChannel = async (channel) => {
    setActiveChat(channel); setChatType('room'); setCurrentId(channel._id); clearUnread(channel._id);
    try {
      if (socket) socket.emit('join_chat', channel._id);
      const historyRes = await axios.get(`/channels/${channel._id}/messages`);
      setMessages(historyRes.data);
    } catch (error) { console.error('Error joining channel', error); }
  };

  const handleCreateServer = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/servers', { name: newServerName });
      setServers([...servers, res.data]); setShowCreateServer(false); setNewServerName(''); setActiveServer(res.data);
    } catch (error) { alert('Error creating server'); }
  };

  const handleJoinServer = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/servers/join', { inviteCode: joinInviteCode });
      setServers([...servers, res.data]); setShowJoinServer(false); setJoinInviteCode(''); setActiveServer(res.data);
    } catch (error) { alert(error.response?.data?.message || 'Error joining server'); }
  };

  const handleCreateChannel = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`/servers/${activeServer._id}/channels`, { name: newChannelName, type: 'text' });
      setChannels([...channels, res.data]); setShowCreateChannel(false); setNewChannelName('');
    } catch (error) { alert(error.response?.data?.message || 'Error creating channel'); }
  };

  // Phase 9: RBAC Handlers
  const handleCreateRole = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`/servers/${activeServer._id}/roles`, {
        name: newRoleName, color: newRoleColor, permissions: newRolePerms
      });
      setActiveServer(res.data);
      setNewRoleName('');
      setNewRolePerms({ MANAGE_SERVER: false, MANAGE_CHANNELS: false, MANAGE_ROLES: false, KICK_MEMBERS: false });
      alert('Role created successfully!');
    } catch (error) { alert(error.response?.data?.message || 'Error creating role'); }
  };

  const handleAssignRole = async (userId, roleId) => {
    try {
      const res = await axios.post(`/servers/${activeServer._id}/members/${userId}/roles`, { roleId });
      setActiveServer(res.data);
    } catch (error) { alert(error.response?.data?.message || 'Error assigning role'); }
  };

  const handleKickMember = async (userId) => {
    try {
      const res = await axios.delete(`/servers/${activeServer._id}/members/${userId}`);
      setActiveServer(res.data);
    } catch (error) { alert(error.response?.data?.message || 'Error kicking member'); }
  };

  // Phase 10: Toggle Reaction Handler
  const handleToggleReaction = async (messageId, emoji) => {
    try {
      const res = await axios.post(`/chat/messages/${messageId}/react`, { emoji });
      const updatedMsg = res.data;
      setMessages(prev => prev.map(m => m._id === messageId ? updatedMsg : m));
      if (socket) {
        socket.emit('toggle_reaction', { messageId, roomId: currentId, updatedMessage: updatedMsg });
      }
    } catch (error) { console.error('Error reacting to message', error); }
  };

  // Phase 10: Global Search Handler
  const handleSearchMessages = async () => {
    if (!searchQuery.trim()) return;
    try {
      let params = { q: searchQuery };
      if (activeServer) {
        params.serverId = activeServer._id;
      } else if (activeChat) {
        if (chatType === 'dm') {
          params.conversationId = currentId;
        } else {
          params.channelId = activeChat._id;
        }
      }
      const res = await axios.get('/chat/search', { params });
      setMessageSearchResults(res.data);
      setShowSearchModal(true);
    } catch (error) { console.error('Error searching messages', error); }
  };

  // Profile & Friend
  const handleSearchUsers = async (e) => {
    e.preventDefault(); if (!addFriendInput.trim()) return;
    setIsSearching(true);
    try {
      const res = await axios.get(`/friends/search?q=${addFriendInput}`);
      setSearchResults(res.data);
    } catch (error) { console.error('Error searching', error); } finally { setIsSearching(false); }
  };

  const handleSendFriendRequest = async (username) => {
    try {
      await axios.post('/friends/request', { username });
      setSearchResults(prev => prev.map(u => u.username === username ? {...u, requestSent: true} : u));
    } catch (error) { alert(error.response?.data?.message || 'Error'); }
  };

  const handleAcceptRequest = async (id) => { await axios.post(`/friends/request/${id}/accept`); setPendingRequests(prev => prev.filter(r => r._id !== id)); fetchData(); };
  const handleRejectRequest = async (id) => { await axios.post(`/friends/request/${id}/reject`); setPendingRequests(prev => prev.filter(r => r._id !== id)); };

  const handleUpdateProfile = async (e) => {
    e.preventDefault(); await axios.put('/auth/profile', { bio: bioInput }); alert('Profile updated!'); setShowSettings(false);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const formData = new FormData(); formData.append('file', file);
    const res = await axios.post('/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
    await axios.put('/auth/profile', { profilePic: res.data.url }); alert('Avatar updated!');
  };

  const handleInput = (e) => {
    setNewMessage(e.target.value);
    if (!socket || !currentId) return;
    socket.emit('typing', { conversationId: currentId, userId: user._id });
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => { socket.emit('stop_typing', { conversationId: currentId, userId: user._id }); }, 2000);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0]; if (!file || !activeChat) return;
    setUploading(true);
    const formData = new FormData(); formData.append('file', file);
    try {
      const uploadRes = await axios.post('/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      const type = file.type.startsWith('image/') ? 'image' : 'file';
      const url = chatType === 'dm' ? '/chat/messages' : `/channels/${activeChat._id}/messages`;
      const payload = chatType === 'dm' ? 
        { receiverId: activeChat._id, text: 'Shared an attachment', type, fileUrl: uploadRes.data.url, replyTo: replyingToMessage?._id } : 
        { text: 'Shared an attachment', type, fileUrl: uploadRes.data.url, replyTo: replyingToMessage?._id };
      const res = await axios.post(url, payload);
      const sentMessage = chatType === 'dm' ? res.data.message : res.data;
      setMessages((prev) => [...prev, sentMessage]);
      if (socket && currentId) socket.emit('send_message', sentMessage);
      setReplyingToMessage(null);
    } catch (error) { alert('Upload failed'); } finally { setUploading(false); e.target.value = null; }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault(); if (!newMessage.trim() || !activeChat) return;
    if (socket) socket.emit('stop_typing', { conversationId: currentId, userId: user._id });
    if (editingMessage) {
      const res = await axios.put(`/chat/messages/${editingMessage._id}`, { text: newMessage });
      const updatedMsg = res.data.updatedMessage;
      setMessages((prev) => prev.map((m) => m._id === updatedMsg._id ? updatedMsg : m));
      if (socket && currentId) socket.emit('edit_message', updatedMsg);
      setEditingMessage(null); setNewMessage(''); return;
    }
    try {
      const url = chatType === 'dm' ? '/chat/messages' : `/channels/${activeChat._id}/messages`;
      const payload = chatType === 'dm' ? 
        { receiverId: activeChat._id, text: newMessage, type: 'text', replyTo: replyingToMessage?._id } : 
        { text: newMessage, type: 'text', replyTo: replyingToMessage?._id };
      const res = await axios.post(url, payload);
      const sentMessage = chatType === 'dm' ? res.data.message : res.data;
      setMessages((prev) => [...prev, sentMessage]); setNewMessage('');
      if (socket && currentId) socket.emit('send_message', sentMessage);
      setReplyingToMessage(null);
    } catch (error) { console.error(error); alert(error.response?.data?.message || 'Failed to send'); }
  };

  const handleDeleteMessage = async (messageId) => {
    await axios.delete(`/chat/messages/${messageId}`);
    setMessages((prev) => prev.filter((m) => m._id !== messageId));
    if (socket && currentId) socket.emit('delete_message', { messageId, roomId: currentId });
  };

  // PREMIUM STYLING UTILS
  const glassPanel = "bg-[#09090b]/90 backdrop-blur-3xl border border-white/10 shadow-2xl";
  const neonText = "bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400 font-bold";

  return (
    <div className="flex h-screen bg-gradient-to-br from-[#07080e] via-[#0d0e1b] to-[#16142e] text-white overflow-hidden font-sans selection:bg-indigo-500/30 relative">
      <CosmicBackground />
      
      {/* Background Orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-600/10 blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-purple-600/10 blur-[120px]" />
      </div>

      {/* Global Search Drawer */}
      {showSearchModal && (
        <div className="fixed inset-y-0 right-0 w-[400px] bg-[#09090b]/95 backdrop-blur-2xl border-l border-white/10 shadow-2xl z-40 flex flex-col p-6 animate-in slide-in-from-right duration-300">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold flex items-center"><Search className="w-5 h-5 mr-2 text-indigo-400" /> Search Results</h2>
            <button onClick={() => { setShowSearchModal(false); setMessageSearchResults([]); setSearchQuery(''); }} className="text-gray-400 hover:text-white bg-white/5 p-1.5 rounded-full"><X className="w-4 h-4"/></button>
          </div>
          <div className="flex-1 overflow-y-auto space-y-4 custom-scrollbar">
            {messageSearchResults.length === 0 ? (
              <div className="text-gray-500 text-sm text-center mt-12">No messages match your search.</div>
            ) : messageSearchResults.map(msg => (
              <div key={msg._id} className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-indigo-300">@{msg.sender?.username}</span>
                  <span className="text-gray-500">{new Date(msg.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="text-sm text-gray-200 break-words">{msg.text}</div>
                {msg.roomId && (
                  <div className="text-[10px] text-gray-500 bg-white/5 px-2 py-0.5 rounded-lg inline-block">Channel search result</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Server Settings Modal (Phase 9) */}
      {showServerSettings && activeServer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-200">
          <div className={`w-full max-w-4xl h-[600px] flex rounded-3xl overflow-hidden ${glassPanel} border-indigo-500/20`}>
            {/* Left Sidebar */}
            <div className="w-64 bg-black/40 p-6 flex flex-col border-r border-white/5">
               <h3 className={`text-xs uppercase tracking-widest mb-6 ${neonText}`}>{activeServer.name}</h3>
               <div className="space-y-1">
                 <button onClick={() => setServerSettingsTab('overview')} className={`w-full text-left px-4 py-2.5 rounded-xl font-medium transition-all ${serverSettingsTab === 'overview' ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>Overview</button>
                 <button onClick={() => setServerSettingsTab('roles')} className={`w-full text-left px-4 py-2.5 rounded-xl font-medium transition-all ${serverSettingsTab === 'roles' ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>Roles & Permissions</button>
                 <button onClick={() => setServerSettingsTab('members')} className={`w-full text-left px-4 py-2.5 rounded-xl font-medium transition-all ${serverSettingsTab === 'members' ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>Member Management</button>
               </div>
               <button onClick={() => setShowServerSettings(false)} className="mt-auto flex items-center text-red-400 hover:text-red-300 px-4 py-2"><LogOut className="w-4 h-4 mr-2"/> Close Settings</button>
            </div>
            {/* Right Content */}
            <div className="flex-1 p-8 overflow-y-auto custom-scrollbar relative bg-gradient-to-br from-white/[0.02] to-transparent">
               {serverSettingsTab === 'overview' && (
                 <div>
                    <h2 className="text-2xl font-bold mb-6 text-white">Server Overview</h2>
                    <div className="bg-black/40 p-6 rounded-2xl border border-white/5 flex items-center space-x-6">
                       <div className="w-24 h-24 rounded-full bg-indigo-500/20 flex items-center justify-center border-2 border-indigo-500/50">
                         {activeServer.icon ? <img src={activeServer.icon} className="w-full h-full rounded-full object-cover" /> : <span className="text-3xl font-bold text-indigo-400">{activeServer.name[0]}</span>}
                       </div>
                       <div>
                         <div className="text-sm text-gray-400 mb-1">Server Name</div>
                         <div className="text-xl font-semibold text-white mb-4">{activeServer.name}</div>
                         <div className="text-sm text-gray-400 mb-1">Invite Code</div>
                         <div className="bg-black/50 px-3 py-1.5 rounded-lg border border-white/10 font-mono text-indigo-300 inline-block">{activeServer.inviteCode}</div>
                       </div>
                    </div>
                 </div>
               )}
               {serverSettingsTab === 'roles' && (
                 <div>
                    <h2 className="text-2xl font-bold mb-2 text-white">Role Management</h2>
                    <p className="text-gray-400 text-sm mb-6">Create roles to assign specialized permissions to members.</p>
                    
                    <div className="grid grid-cols-2 gap-8">
                       <div className="space-y-4">
                         <h3 className="text-sm font-semibold text-indigo-400 uppercase tracking-wider mb-2">Existing Roles</h3>
                         {activeServer.roles?.length === 0 ? <div className="text-gray-500 text-sm">No custom roles created.</div> : activeServer.roles?.map(r => (
                           <div key={r._id} className="bg-black/40 p-4 rounded-2xl border border-white/5 flex items-center justify-between group">
                              <div className="flex items-center">
                                <div className="w-3 h-3 rounded-full mr-3" style={{backgroundColor: r.color}}></div>
                                <span className="font-medium text-white">{r.name}</span>
                              </div>
                              <ShieldAlert className="w-4 h-4 text-gray-600 group-hover:text-indigo-400 transition-colors" />
                           </div>
                         ))}
                       </div>
                       
                       <div className="bg-black/40 p-6 rounded-3xl border border-white/5">
                         <h3 className="text-sm font-semibold text-indigo-400 uppercase tracking-wider mb-4">Create New Role</h3>
                         <form onSubmit={handleCreateRole} className="space-y-4">
                           <div>
                             <label className="block text-xs text-gray-400 mb-1">Role Name</label>
                             <input type="text" required value={newRoleName} onChange={e=>setNewRoleName(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all" placeholder="e.g. Moderator" />
                           </div>
                           <div>
                             <label className="block text-xs text-gray-400 mb-1">Role Color</label>
                             <div className="flex items-center space-x-3">
                               <input type="color" value={newRoleColor} onChange={e=>setNewRoleColor(e.target.value)} className="w-10 h-10 rounded cursor-pointer bg-transparent border-0" />
                               <span className="text-sm text-gray-400 font-mono">{newRoleColor}</span>
                             </div>
                           </div>
                           <div className="pt-2 border-t border-white/5">
                             <label className="block text-xs font-semibold text-gray-300 mb-3 uppercase">Permissions</label>
                             {Object.keys(newRolePerms).map(perm => (
                               <label key={perm} className="flex items-center justify-between py-2 cursor-pointer group">
                                 <span className="text-sm text-gray-400 group-hover:text-gray-200 transition-colors">{perm.replace('_', ' ')}</span>
                                 <input type="checkbox" checked={newRolePerms[perm]} onChange={e => setNewRolePerms({...newRolePerms, [perm]: e.target.checked})} className="w-4 h-4 rounded border-gray-600 text-indigo-500 focus:ring-indigo-500 bg-black/50" />
                               </label>
                             ))}
                           </div>
                           <button type="submit" className="w-full mt-4 bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl font-medium transition-all shadow-lg shadow-indigo-500/20">Create Role</button>
                         </form>
                       </div>
                    </div>
                 </div>
               )}
               {serverSettingsTab === 'members' && (
                 <div>
                    <h2 className="text-2xl font-bold mb-6 text-white">Member Management</h2>
                    <div className="space-y-2">
                       {/* Simplified member list for demo */}
                       <div className="bg-black/40 p-4 rounded-2xl border border-white/5 flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                             <div className="w-10 h-10 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 font-bold">O</div>
                             <div>
                               <div className="font-medium text-white">Owner / You</div>
                               <div className="text-xs text-indigo-400">Server Creator</div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
               )}
            </div>
          </div>
        </div>
      )}

      {/* User Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-200">
          <div className={`w-full max-w-md p-8 rounded-3xl overflow-hidden ${glassPanel} border-purple-500/20`}>
            <div className="flex justify-between items-center mb-8">
              <h2 className={`text-2xl font-bold ${neonText}`}>Your Profile</h2>
              <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-white transition-colors bg-white/5 p-2 rounded-full"><X className="w-5 h-5"/></button>
            </div>
            <div className="flex flex-col items-center mb-8 relative">
              <div className="w-32 h-32 rounded-full bg-indigo-500/10 flex items-center justify-center overflow-hidden border-2 border-indigo-500/30 mb-4 group cursor-pointer shadow-[0_0_30px_-5px_rgba(99,102,241,0.4)]" onClick={() => avatarInputRef.current?.click()}>
                {user.profilePic ? <img src={user.profilePic} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" /> : <span className="text-5xl font-bold text-indigo-400">{user.username.charAt(0).toUpperCase()}</span>}
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                  <ImageIcon className="w-8 h-8 text-white" />
                </div>
              </div>
              <input type="file" ref={avatarInputRef} onChange={handleAvatarUpload} className="hidden" accept="image/*" />
            </div>
            <form onSubmit={handleUpdateProfile}>
              <div className="mb-6">
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">About Me</label>
                <textarea value={bioInput} onChange={(e) => setBioInput(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-gray-200 focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 resize-none h-28 transition-all" placeholder="Write something cool..." />
              </div>
              <button type="submit" className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl hover:from-indigo-500 hover:to-purple-500 transition-all font-medium shadow-lg shadow-indigo-500/25">Save Changes</button>
            </form>
          </div>
        </div>
      )}

      {/* Far Left Sidebar (Server List) */}
      <div className="w-[80px] bg-black/35 backdrop-blur-2xl border-r border-white/[0.06] flex flex-col items-center py-4 z-30 flex-shrink-0">
        <button 
          onClick={() => { setActiveServer(null); setActiveChat(null); setFriendsTab('online'); }} 
          className={`w-14 h-14 flex items-center justify-center transition-all duration-300 relative group ${!activeServer ? 'bg-gradient-to-br from-indigo-500 to-purple-500 text-white rounded-2xl shadow-lg shadow-indigo-500/30' : 'bg-white/5 text-gray-300 rounded-[28px] hover:rounded-2xl hover:bg-indigo-500 hover:text-white'}`}
        >
          <SyncoraLogo className="w-7 h-7" />
          <div className={`absolute left-0 w-1 bg-white rounded-r-lg transition-all duration-300 ${!activeServer ? 'h-10' : 'h-0 group-hover:h-5 -ml-4'}`} />
        </button>
        
        <div className="w-8 h-[2px] bg-white/10 rounded-full my-4" />
        
        <div className="flex-1 overflow-y-auto w-full flex flex-col items-center space-y-3 custom-scrollbar hide-scrollbar">
          {servers.map(s => (
            <button 
              key={s._id} onClick={() => setActiveServer(s)} 
              className={`w-14 h-14 flex items-center justify-center transition-all duration-300 relative group ${activeServer?._id === s._id ? 'bg-gradient-to-br from-indigo-500 to-purple-500 text-white rounded-2xl shadow-lg shadow-indigo-500/30' : 'bg-white/5 text-gray-300 rounded-[28px] hover:rounded-2xl hover:bg-indigo-500 hover:text-white'}`}
            >
              {s.icon ? <img src={s.icon} className="w-full h-full rounded-inherit object-cover" /> : <span className="font-bold text-xl">{s.name[0].toUpperCase()}</span>}
              <div className={`absolute left-0 w-1 bg-white rounded-r-lg transition-all duration-300 ${activeServer?._id === s._id ? 'h-10' : 'h-0 group-hover:h-5 -ml-4'}`} />
            </button>
          ))}
          
          <button onClick={() => setShowCreateServer(true)} className="w-14 h-14 rounded-[28px] bg-white/5 text-emerald-400 flex items-center justify-center hover:bg-emerald-500 hover:text-white hover:rounded-2xl transition-all duration-300 group shadow-lg shadow-black/20">
            <Plus className="w-6 h-6" />
          </button>
          <button onClick={() => setShowJoinServer(true)} className="w-14 h-14 rounded-[28px] bg-white/5 text-emerald-400 flex items-center justify-center hover:bg-emerald-500 hover:text-white hover:rounded-2xl transition-all duration-300 group shadow-lg shadow-black/20" title="Join Server">
            <Compass className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Inner Sidebar (Channels or Friends) */}
      <div className="w-[280px] bg-[#0c0e18]/65 backdrop-blur-3xl border-r border-white/[0.06] flex flex-col z-20 flex-shrink-0 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 to-transparent pointer-events-none" />
        
        {!activeServer ? (
          <>
            <div className="h-16 border-b border-white/5 flex items-center px-4 relative z-10">
              <button className="w-full bg-black/40 border border-white/5 text-gray-400 text-sm px-4 py-2 rounded-xl text-left hover:bg-black/60 transition-colors flex items-center">
                Search friends...
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 custom-scrollbar space-y-1 relative z-10">
              <button onClick={() => { setActiveChat(null); }} className={`w-full flex items-center px-4 py-3 rounded-xl transition-all duration-200 mb-6 ${!activeChat ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'hover:bg-white/5 text-gray-400 hover:text-gray-200'}`}>
                <Users className="w-5 h-5 mr-3" /> <span className="font-semibold">Friends</span>
              </button>
              <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-3 hover:text-gray-400 transition-colors">Direct Messages</div>
              {friends.map(u => (
                <button key={u._id} onClick={() => startDM(u)} className={`w-full flex items-center px-3 py-2.5 rounded-xl group transition-all duration-200 relative ${activeChat?._id === u._id ? 'bg-indigo-500/10 text-white border border-indigo-500/20 shadow-[0_0_15px_-3px_rgba(99,102,241,0.2)]' : 'hover:bg-white/5 text-gray-400 hover:text-gray-200 border border-transparent'}`}>
                  <div className="relative mr-4">
                    <div className="w-10 h-10 rounded-full bg-black/50 flex items-center justify-center overflow-hidden border border-white/5 group-hover:border-indigo-500/50 transition-colors">
                      {u.profilePic ? <img src={u.profilePic} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-gray-500" />}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[#09090b] ${u.status === 'online' ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'bg-gray-500'}`} />
                  </div>
                  <div className="flex-1 text-left truncate font-medium">{u.username}</div>
                  {unreadCounts[u._id] && <div className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-lg">{unreadCounts[u._id]}</div>}
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <div onClick={() => { if(activeServer.owner === user._id) setShowServerSettings(true); }} className="h-16 border-b border-white/5 flex items-center justify-between px-5 hover:bg-white/5 cursor-pointer transition-colors group relative z-10">
              <span className="font-bold text-white truncate text-lg">{activeServer.name}</span>
              {activeServer.owner === user._id && <Settings className="w-5 h-5 text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />}
            </div>
            <div className="flex-1 overflow-y-auto p-3 custom-scrollbar relative z-10">
              <div className="flex items-center justify-between text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 px-2 hover:text-gray-400 transition-colors group">
                <span>Text Channels</span>
                <button onClick={() => setShowCreateChannel(true)} className="hover:text-white"><Plus className="w-4 h-4" /></button>
              </div>
              {channels.map(c => (
                <button key={c._id} onClick={() => joinChannel(c)} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center space-x-2 mb-1 transition-all duration-200 border ${activeChat?._id === c._id ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20 shadow-[0_0_15px_-3px_rgba(99,102,241,0.2)]' : 'border-transparent text-gray-400 hover:bg-white/5 hover:text-gray-200'}`}>
                  <Hash className={`w-5 h-5 ${activeChat?._id === c._id ? 'text-indigo-400' : 'text-gray-500'}`} />
                  <span className="font-medium truncate">{c.name}</span>
                  {unreadCounts[c._id] && <div className="bg-white text-black text-[10px] font-bold px-1.5 rounded-full ml-auto shadow-lg">{unreadCounts[c._id]}</div>}
                </button>
              ))}
            </div>
          </>
        )}
        
        {/* User Strip */}
        <div className="h-[72px] bg-black/40 backdrop-blur-md border-t border-white/5 flex items-center px-4 mt-auto relative z-10">
          <div className="flex items-center space-x-3 flex-1 hover:bg-white/5 p-2 rounded-xl cursor-pointer transition-colors overflow-hidden border border-transparent hover:border-white/5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-black/50 overflow-hidden flex items-center justify-center border border-white/10">
                 {user.profilePic ? <img src={user.profilePic} className="w-full h-full object-cover" /> : <span className="font-bold text-indigo-400">{user.username[0].toUpperCase()}</span>}
              </div>
              <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#09090b] bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
            </div>
            <div className="flex flex-col truncate">
              <span className="text-sm font-bold text-white leading-tight">{user.username}</span>
              <span className="text-[11px] text-gray-400 leading-tight">Online</span>
            </div>
          </div>
          <div className="flex space-x-1 ml-2">
            <button onClick={() => setShowSettings(true)} className="p-2 hover:bg-white/10 rounded-xl text-gray-400 hover:text-white transition-colors"><Settings className="w-5 h-5" /></button>
            <button onClick={logout} className="p-2 hover:bg-red-500/10 rounded-xl text-gray-400 hover:text-red-400 transition-colors"><LogOut className="w-5 h-5" /></button>
          </div>
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex flex-col relative bg-transparent z-10">
        
        {/* Modals for Create/Join (Truncated for brevity but styled) */}
        {showCreateServer && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center animate-in fade-in zoom-in-95 p-4">
            <div className={`w-full max-w-md p-8 rounded-3xl ${glassPanel}`}>
              <h2 className={`text-2xl font-bold mb-2 ${neonText}`}>Create a server</h2>
              <p className="text-gray-400 text-sm mb-8">Give your new server a personality with a name.</p>
              <form onSubmit={handleCreateServer}>
                <div className="mb-8">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Server Name</label>
                  <input type="text" required value={newServerName} onChange={e => setNewServerName(e.target.value)} className="w-full bg-black/40 border border-white/10 p-4 rounded-2xl text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all" />
                </div>
                <div className="flex justify-between items-center">
                  <button type="button" onClick={() => setShowCreateServer(false)} className="text-sm font-medium text-gray-400 hover:text-white">Cancel</button>
                  <button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-3 rounded-xl text-white font-medium hover:from-indigo-500 hover:to-purple-500 transition-all shadow-lg shadow-indigo-500/25">Create</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showJoinServer && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center animate-in fade-in zoom-in-95 p-4">
            <div className={`w-full max-w-md p-8 rounded-3xl ${glassPanel}`}>
              <h2 className={`text-2xl font-bold mb-2 ${neonText}`}>Join a Server</h2>
              <p className="text-gray-400 text-sm mb-8">Enter an invite code to connect with your friends.</p>
              <form onSubmit={handleJoinServer}>
                <div className="mb-8">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Invite Code</label>
                  <input type="text" required value={joinInviteCode} onChange={e => setJoinInviteCode(e.target.value)} placeholder="e.g. h8d9f2" className="w-full bg-black/40 border border-white/10 p-4 rounded-2xl text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono" />
                </div>
                <div className="flex justify-between items-center">
                  <button type="button" onClick={() => setShowJoinServer(false)} className="text-sm font-medium text-gray-400 hover:text-white">Cancel</button>
                  <button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-3 rounded-xl text-white font-medium hover:from-indigo-500 hover:to-purple-500 transition-all shadow-lg shadow-indigo-500/25">Join Server</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showCreateChannel && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center animate-in fade-in zoom-in-95 p-4">
            <div className={`w-full max-w-md p-8 rounded-3xl ${glassPanel}`}>
              <h2 className={`text-2xl font-bold mb-2 ${neonText}`}>Create Text Channel</h2>
              <p className="text-gray-400 text-sm mb-8">Set a name for the server channel.</p>
              <form onSubmit={handleCreateChannel}>
                <div className="mb-8">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Channel Name</label>
                  <input type="text" required value={newChannelName} onChange={e => setNewChannelName(e.target.value)} placeholder="e.g. general" className="w-full bg-black/40 border border-white/10 p-4 rounded-2xl text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all" />
                </div>
                <div className="flex justify-between items-center">
                  <button type="button" onClick={() => setShowCreateChannel(false)} className="text-sm font-medium text-gray-400 hover:text-white">Cancel</button>
                  <button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-3 rounded-xl text-white font-medium hover:from-indigo-500 hover:to-purple-500 transition-all shadow-lg shadow-indigo-500/25">Create Channel</button>
                </div>
              </form>
            </div>
          </div>
        )}
        
        {/* Top Header */}
        <div className="h-16 border-b border-white/5 flex items-center justify-between px-6 bg-black/20 backdrop-blur-sm z-20">
          <div className="flex items-center space-x-3">
             {!activeChat && !activeServer ? (
                <div className="flex items-center text-white font-bold text-lg"><Users className="w-6 h-6 mr-3 text-gray-400"/> Friends</div>
             ) : activeChat ? (
               <>
                 {chatType === 'dm' ? <User className="w-6 h-6 text-indigo-400" /> : <Hash className="w-6 h-6 text-gray-400" />}
                 <span className="font-bold text-white text-lg">{chatType === 'dm' ? activeChat.username : activeChat.name}</span>
               </>
             ) : null}
          </div>
          
          {/* Global Search Header Area (Phase 10) */}
          {(activeChat || activeServer) && (
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search messages..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSearchMessages(); }}
                className="bg-black/40 border border-white/10 text-xs px-3 py-1.5 rounded-xl text-gray-200 focus:outline-none focus:border-indigo-500 w-48 pr-8"
              />
              <Search className="w-3.5 h-3.5 text-gray-500 absolute right-2.5 top-2.5 pointer-events-none" />
            </div>
          )}
        </div>

        {/* Dynamic Content */}
        {!activeChat && !activeServer ? (
          /* Friends Dashboard */
          <div className="flex-1 flex flex-col relative z-10">
            <div className="px-8 py-5 flex space-x-6 border-b border-white/5 bg-black/20 backdrop-blur-sm">
              <button onClick={() => setFriendsTab('online')} className={`font-medium transition-colors ${friendsTab === 'online' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}>Online</button>
              <button onClick={() => setFriendsTab('all')} className={`font-medium transition-colors ${friendsTab === 'all' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}>All</button>
              <button onClick={() => setFriendsTab('pending')} className={`font-medium flex items-center transition-colors ${friendsTab === 'pending' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}>Pending {pendingRequests.length > 0 && <span className="ml-2 bg-rose-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center">{pendingRequests.length}</span>}</button>
              <button onClick={() => setFriendsTab('add')} className={`px-4 py-1 rounded-lg text-sm font-bold transition-all ${friendsTab === 'add' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' : 'bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white'}`}>Add Friend</button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
              {friendsTab === 'online' && (
                <div className="space-y-2">
                  {friends.filter(f => f.status === 'online').length === 0 ? (
                    <div className="text-gray-500 text-sm">No one is online right now.</div>
                  ) : friends.filter(f => f.status === 'online').map(f => (
                    <div key={f._id} className="flex items-center justify-between p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:border-white/10 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="relative">
                          <div className="w-10 h-10 rounded-full bg-black/50 overflow-hidden flex items-center justify-center border border-white/5">
                            {f.profilePic ? <img src={f.profilePic} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-gray-500" />}
                          </div>
                          <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#09090b] bg-emerald-500" />
                        </div>
                        <div>
                          <div className="font-semibold">{f.username}</div>
                          <div className="text-xs text-gray-400">{f.bio || 'No status'}</div>
                        </div>
                      </div>
                      <button onClick={() => startDM(f)} className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500 hover:text-white px-4 py-2 rounded-xl text-sm font-medium transition-all">Message</button>
                    </div>
                  ))}
                </div>
              )}

              {friendsTab === 'all' && (
                <div className="space-y-2">
                  {friends.length === 0 ? (
                    <div className="text-gray-500 text-sm">No friends added yet.</div>
                  ) : friends.map(f => (
                    <div key={f._id} className="flex items-center justify-between p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:border-white/10 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="relative">
                          <div className="w-10 h-10 rounded-full bg-black/50 overflow-hidden flex items-center justify-center border border-white/5">
                            {f.profilePic ? <img src={f.profilePic} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-gray-500" />}
                          </div>
                          <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#09090b] ${f.status === 'online' ? 'bg-emerald-500' : 'bg-gray-500'}`} />
                        </div>
                        <div>
                          <div className="font-semibold">{f.username}</div>
                          <div className="text-xs text-gray-400">{f.bio || 'No status'}</div>
                        </div>
                      </div>
                      <button onClick={() => startDM(f)} className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500 hover:text-white px-4 py-2 rounded-xl text-sm font-medium transition-all">Message</button>
                    </div>
                  ))}
                </div>
              )}

              {friendsTab === 'pending' && (
                <div className="space-y-2">
                  {pendingRequests.length === 0 ? (
                    <div className="text-gray-500 text-sm">No pending requests.</div>
                  ) : pendingRequests.map(r => (
                    <div key={r._id} className="flex items-center justify-between p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:border-white/10 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 rounded-full bg-black/50 overflow-hidden flex items-center justify-center border border-white/5">
                          {r.sender?.profilePic ? <img src={r.sender.profilePic} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-gray-500" />}
                        </div>
                        <div>
                          <div className="font-semibold">{r.sender?.username}</div>
                          <div className="text-xs text-gray-400">wants to add you</div>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleAcceptRequest(r._id)} className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all">Accept</button>
                        <button onClick={() => handleRejectRequest(r._id)} className="bg-rose-600 hover:bg-rose-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all">Decline</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {friendsTab === 'add' && (
                <div className="max-w-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className={`text-2xl font-bold mb-2 uppercase ${neonText}`}>Add Friend</h2>
                  <p className="text-gray-400 text-sm mb-8">Search for users to add them to your secure network.</p>
                  <form onSubmit={handleSearchUsers} className="relative flex items-center bg-black/40 border border-white/10 rounded-2xl shadow-sm focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all p-2 mb-8">
                    <input type="text" value={addFriendInput} onChange={(e) => { setAddFriendInput(e.target.value); if(e.target.value === '') setSearchResults([]); }} placeholder="Enter username..." className="flex-1 bg-transparent border-none text-white px-4 py-2 focus:outline-none" />
                    <button type="submit" className="bg-indigo-600 text-white px-8 py-2.5 rounded-xl font-medium hover:bg-indigo-500 transition-colors disabled:opacity-50">Search</button>
                  </form>
                  {/* Results render here... */}
                  {searchResults.map(result => (
                      <div key={result._id} className="flex items-center justify-between p-4 mb-2 bg-black/20 border border-white/5 rounded-2xl hover:border-white/10 transition-colors">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center border border-white/5 overflow-hidden">
                             {result.profilePic ? <img src={result.profilePic} className="w-full h-full object-cover" /> : <User className="w-6 h-6 text-gray-500" />}
                          </div>
                          <span className="font-semibold text-white text-lg">{result.username}</span>
                        </div>
                        <button onClick={() => handleSendFriendRequest(result.username)} className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500 hover:text-white px-6 py-2 rounded-xl font-medium transition-colors">Add</button>
                      </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : activeChat ? (
          <>
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto px-6 py-8 scroll-smooth custom-scrollbar relative z-10">
              {messages.length === 0 ? (
                <div className="mt-auto flex flex-col justify-end h-full animate-in fade-in duration-1000">
                  <div className="w-20 h-20 bg-indigo-500/10 rounded-full flex items-center justify-center mb-6 border border-indigo-500/20 shadow-[0_0_30px_-5px_rgba(99,102,241,0.3)]"><Hash className="w-10 h-10 text-indigo-400" /></div>
                  <h2 className="text-4xl font-bold text-white mb-3">Welcome to <span className={neonText}>{chatType === 'dm' ? activeChat.username : `#${activeChat.name}`}</span>!</h2>
                  <p className="text-gray-400 text-lg">This is the start of the legend.</p>
                </div>
              ) : (
                messages.filter(m => m.text !== 'Started a conversation').map((msg, index) => {
                  const isMine = msg.sender === user._id || msg.sender?._id === user._id;
                  const senderUser = isMine ? user : (msg.sender?.username ? msg.sender : {username: activeChat.username, profilePic: activeChat.profilePic});
                  const showHeader = index === 0 || messages[index - 1].sender?._id !== msg.sender?._id || messages[index - 1].sender !== msg.sender;

                  return (
                    <div 
                      key={msg._id} 
                      className={`flex flex-col group py-1 hover:bg-white/[0.02] px-4 -mx-4 rounded-xl relative transition-colors ${!showHeader ? 'mt-0.5' : 'mt-6'}`}
                      onMouseEnter={() => setHoveredMessageId(msg._id)}
                      onMouseLeave={() => setHoveredMessageId(null)}
                    >
                      {/* Thread Reply Context rendering */}
                      {msg.replyTo && (
                        <div className="flex items-center text-xs text-gray-500 mb-1 ml-14 -mt-1.5">
                          <CornerUpLeft className="w-3.5 h-3.5 mr-1 text-gray-500 transform rotate-180" />
                          <span className="font-bold text-gray-400 mr-1.5">@{msg.replyTo.sender?.username || 'user'}</span>
                          <span className="truncate max-w-[400px] italic">{msg.replyTo.text}</span>
                        </div>
                      )}

                      <div className="flex w-full">
                        {showHeader ? (
                          <div className="w-12 flex-shrink-0 pt-1">
                            <div className="w-10 h-10 rounded-full bg-black/50 overflow-hidden flex items-center justify-center border border-white/5">
                              {senderUser.profilePic ? <img src={senderUser.profilePic} className="w-full h-full object-cover" /> : <User className="w-6 h-6 text-gray-500" />}
                            </div>
                          </div>
                        ) : (
                          <div className="w-12 flex-shrink-0 text-center opacity-0 group-hover:opacity-100 flex items-center justify-center">
                            <span className="text-[10px] text-gray-600 font-medium">{new Date(msg.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                          </div>
                        )}

                        <div className="flex-1 min-w-0 relative">
                          {showHeader && (
                            <div className="flex items-baseline space-x-3 mb-1">
                              <span className="font-semibold text-white hover:underline cursor-pointer">{senderUser.username}</span>
                              <span className="text-xs text-gray-500 font-medium">{new Date(msg.createdAt).toLocaleString()}</span>
                            </div>
                          )}
                          <div className="text-gray-300 leading-relaxed break-words text-[15px] pr-20">
                            {msg.text}
                            {msg.isEdited && <span className="text-[10px] text-gray-600 ml-2 italic">(edited)</span>}
                          </div>

                          {/* Message Reactions display */}
                          {msg.reactions && msg.reactions.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {msg.reactions.map(react => {
                                const hasReacted = react.users.includes(user._id);
                                return (
                                  <button 
                                    key={react.emoji}
                                    onClick={() => handleToggleReaction(msg._id, react.emoji)}
                                    className={`flex items-center space-x-1.5 px-2 py-0.5 rounded-lg border text-xs transition-all ${hasReacted ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-black/40 border-white/10 text-gray-400 hover:border-white/20'}`}
                                  >
                                    <span>{react.emoji}</span>
                                    <span className="font-bold text-[10px]">{react.users.length}</span>
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* Action Overlay: Reactions & Replies (Hover menus) */}
                          {hoveredMessageId === msg._id && (
                            <div className="absolute right-0 top-0 bg-[#0f0f15] border border-white/10 rounded-xl px-2 py-1 flex items-center space-x-1 shadow-xl z-20 transition-all">
                              {/* Standard reactions */}
                              {['👍', '❤️', '😂', '🔥'].map(emoji => (
                                <button 
                                  key={emoji} 
                                  onClick={() => handleToggleReaction(msg._id, emoji)}
                                  className="hover:bg-white/10 p-1.5 rounded-lg text-sm transition-colors"
                                >
                                  {emoji}
                                </button>
                              ))}
                              
                              <div className="w-[1px] h-4 bg-white/10 mx-1" />
                              
                              {/* Reply trigger button */}
                              <button 
                                onClick={() => setReplyingToMessage(msg)}
                                className="hover:bg-indigo-500/20 text-gray-400 hover:text-indigo-400 p-1.5 rounded-lg transition-colors"
                                title="Reply"
                              >
                                <CornerUpLeft className="w-4 h-4" />
                              </button>
                              
                              {isMine && (
                                <>
                                  <button onClick={() => { setEditingMessage(msg); setNewMessage(msg.text); }} className="hover:bg-white/10 text-gray-400 hover:text-white p-1.5 rounded-lg transition-colors"><Pencil className="w-4 h-4" /></button>
                                  <button onClick={() => handleDeleteMessage(msg._id)} className="hover:bg-rose-500/20 text-gray-400 hover:text-rose-400 p-1.5 rounded-lg transition-colors"><X className="w-4 h-4" /></button>
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} className="h-6" />
            </div>

            {/* Input Form */}
            <div className="px-6 pb-8 pt-2 shrink-0 relative z-20">
               {/* Reply context bar (Phase 10) */}
               {replyingToMessage && (
                  <div className="bg-white/5 border border-white/10 border-b-0 rounded-t-2xl px-4 py-2.5 flex items-center justify-between text-xs text-gray-400 backdrop-blur-md">
                     <span className="flex items-center">
                        <CornerUpLeft className="w-4 h-4 mr-2 text-indigo-400" />
                        Replying to <span className="text-indigo-300 font-bold ml-1">@{replyingToMessage.sender?.username || (replyingToMessage.sender === user._id ? user.username : activeChat?.username)}</span>
                     </span>
                     <button onClick={() => setReplyingToMessage(null)} className="hover:text-white bg-white/5 p-1 rounded-full"><X className="w-3.5 h-3.5"/></button>
                  </div>
               )}

               <form onSubmit={handleSendMessage} className={`flex items-center bg-black/40 border border-white/5 backdrop-blur-xl shadow-2xl focus-within:border-indigo-500/50 focus-within:ring-1 focus-within:ring-indigo-500/30 transition-all ${editingMessage ? 'rounded-b-2xl' : (replyingToMessage ? 'rounded-b-2xl' : 'rounded-2xl')} p-1.5`}>
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="p-3 text-gray-400 hover:text-white transition-colors bg-white/5 hover:bg-white/10 rounded-xl ml-1">
                     <Plus className="w-5 h-5" />
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
                  <input
                    type="text"
                    value={newMessage}
                    onChange={handleInput}
                    placeholder={editingMessage ? "Edit your message..." : `Message ${chatType === 'dm' ? '@' + activeChat.username : '#' + activeChat.name}`}
                    className="flex-1 bg-transparent text-gray-200 py-3 px-4 focus:outline-none placeholder-gray-600 text-[15px]"
                  />
                  <button type="submit" disabled={!newMessage.trim()} className="p-3 bg-indigo-600 rounded-xl text-white hover:bg-indigo-500 transition-colors disabled:opacity-50 disabled:bg-white/5 mr-1 shadow-lg shadow-indigo-500/20">
                     <Send className="w-5 h-5" />
                  </button>
               </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center bg-transparent relative z-10 p-8 text-center animate-in fade-in duration-500">
             <div className="relative mb-6">
                {/* Glowing ring under logo */}
                <div className="absolute inset-0 m-auto w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl animate-pulse" />
                <SyncoraLogo className="w-28 h-28 relative z-10 animate-[spin_40s_linear_infinite]" />
             </div>
             <h2 className="text-3xl font-extrabold text-white mb-2.5 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-100 to-indigo-300">
                Welcome to Syncora
             </h2>
             <p className="text-gray-400 text-sm max-w-[280px] leading-relaxed mb-6">
                Connect with servers, message friends, and experience instant real-time synchronization.
             </p>
             <div className="text-xs text-gray-500 font-medium bg-white/[0.02] border border-white/5 px-4 py-2 rounded-full">
                Select a channel or friend on the left to start syncing!
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatApp;
