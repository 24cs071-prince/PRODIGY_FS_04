import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Mail, Lock, User, Loader2, Sparkles, Zap, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

// Custom Syncora Branding Logo
const SyncoraLogo = ({ className = "w-10 h-10" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="50" rx="38" ry="14" transform="rotate(-30 50 50)" className="stroke-indigo-500/30" strokeWidth="1.5" strokeDasharray="4 4" />
    <ellipse cx="50" cy="50" rx="38" ry="14" transform="rotate(45 50 50)" className="stroke-purple-500/40" strokeWidth="1.5" />
    <ellipse cx="50" cy="50" rx="28" ry="10" transform="rotate(15 50 50)" className="stroke-indigo-400" strokeWidth="2.5" />
    <ellipse cx="50" cy="50" rx="28" ry="10" transform="rotate(-60 50 50)" className="stroke-purple-400" strokeWidth="2" />
    <circle cx="50" cy="50" r="12" className="fill-indigo-600/30 stroke-indigo-400" strokeWidth="2" />
    <circle cx="50" cy="50" r="5" className="fill-indigo-300 shadow-[0_0_10px_#818cf8]" />
    <circle cx="75" cy="43" r="3.5" className="fill-indigo-300 animate-pulse" />
    <circle cx="25" cy="57" r="2.5" className="fill-purple-300" />
  </svg>
);

// Twinkling Star background component for cosmic effect
const CosmicBackground = () => {
  const stars = [
    { top: '8%', left: '12%', size: 2, delay: 0.1, duration: 3.5 },
    { top: '18%', left: '78%', size: 3, delay: 1.5, duration: 5.5 },
    { top: '22%', left: '38%', size: 1.5, delay: 0.3, duration: 3 },
    { top: '38%', left: '22%', size: 2.5, delay: 2.2, duration: 4 },
    { top: '50%', left: '88%', size: 2, delay: 0.6, duration: 3.8 },
    { top: '62%', left: '42%', size: 3, delay: 1.8, duration: 5.8 },
    { top: '72%', left: '82%', size: 1.5, delay: 0.4, duration: 4.2 },
    { top: '88%', left: '18%', size: 2, delay: 2.3, duration: 5 },
    { top: '94%', left: '52%', size: 2.5, delay: 1.2, duration: 3.9 },
    { top: '12%', left: '28%', size: 1.5, delay: 0.9, duration: 4.4 },
    { top: '35%', left: '68%', size: 2, delay: 1.7, duration: 4.8 },
    { top: '45%', left: '92%', size: 2.5, delay: 0.5, duration: 3.2 },
    { top: '64%', left: '12%', size: 1.5, delay: 1.3, duration: 4.6 },
    { top: '82%', left: '48%', size: 3, delay: 2.7, duration: 6 },
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {stars.map((star, idx) => (
        <motion.div
          key={idx}
          initial={{ opacity: 0.1, scale: 0.8 }}
          animate={{ opacity: [0.1, 1, 0.1], scale: [0.8, 1.2, 0.8] }}
          transition={{ duration: star.duration, repeat: Infinity, delay: star.delay, ease: "easeInOut" }}
          className="absolute bg-white rounded-full shadow-[0_0_8px_1px_rgba(255,255,255,0.7)]"
          style={{ width: star.size, height: star.size, top: star.top, left: star.left }}
        />
      ))}
      <div className="absolute -top-[30%] -right-[10%] w-[60%] h-[60%] rounded-full bg-indigo-900/20 blur-[130px] animate-pulse" style={{ animationDuration: '9s' }} />
      <div className="absolute -bottom-[30%] -left-[10%] w-[60%] h-[60%] rounded-full bg-purple-900/20 blur-[130px] animate-pulse" style={{ animationDuration: '11s', animationDelay: '1s' }} />
      <div className="absolute top-[40%] right-[30%] w-[300px] h-[300px] rounded-full bg-blue-900/10 blur-[110px] pointer-events-none" />
    </div>
  );
};

// Beautiful constellation SVG representing connected spaces
const SpaceConstellation = () => (
  <div className="relative w-[180px] h-[180px] flex items-center justify-center">
    <svg className="w-full h-full text-indigo-400/35" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Dynamic connection paths */}
      <motion.path 
        d="M 20 20 L 50 15 L 80 30 L 70 70 L 30 80 L 20 20 Z" 
        stroke="currentColor" 
        strokeWidth="1" 
        strokeDasharray="4 3" 
      />
      <path d="M 50 15 L 50 50" stroke="currentColor" strokeWidth="0.8" strokeDasharray="3 3" />
      <path d="M 20 20 L 50 50" stroke="currentColor" strokeWidth="0.8" strokeDasharray="3 3" />
      <path d="M 80 30 L 50 50" stroke="currentColor" strokeWidth="0.8" strokeDasharray="3 3" />
      <path d="M 70 70 L 50 50" stroke="currentColor" strokeWidth="0.8" strokeDasharray="3 3" />
      <path d="M 30 80 L 50 50" stroke="currentColor" strokeWidth="0.8" strokeDasharray="3 3" />

      {/* Nodes (Stars) */}
      <circle cx="20" cy="20" r="4" className="fill-indigo-300 shadow-[0_0_8px_#818cf8]" />
      <circle cx="50" cy="15" r="3" className="fill-purple-300 shadow-[0_0_8px_#c084fc]" />
      <circle cx="80" cy="30" r="4.5" className="fill-blue-300 shadow-[0_0_8px_#93c5fd]" />
      <circle cx="70" cy="70" r="3.5" className="fill-indigo-300 shadow-[0_0_8px_#818cf8]" />
      <circle cx="30" cy="80" r="4" className="fill-purple-300 shadow-[0_0_8px_#c084fc]" />
      
      {/* Central hub (logo spot) */}
      <circle cx="50" cy="50" r="6" className="fill-white animate-ping opacity-25" />
      <circle cx="50" cy="50" r="5" className="fill-indigo-500 shadow-[0_0_12px_#6366f1]" />
    </svg>
    
    <div className="absolute inset-0 m-auto w-10 h-10 bg-indigo-950/70 border border-indigo-500/30 rounded-full flex items-center justify-center shadow-lg">
      <SyncoraLogo className="w-7 h-7" />
    </div>
  </div>
);

const Register = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await register(username, email, password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#07080e] via-[#0d0e1b] to-[#16142e] flex items-center justify-center p-4 relative font-sans overflow-x-hidden">
      {/* Twinkling star layout */}
      <CosmicBackground />

      {/* Header Syncora Branding */}
      <div className="absolute top-6 left-6 z-20 flex items-center space-x-3">
        <SyncoraLogo className="w-9 h-9" />
        <span className="text-white font-bold text-2xl tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-200 to-indigo-400">
          Syncora
        </span>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="w-full max-w-4xl relative z-10 mx-auto"
      >
        {/* Core Glassmorphic Container */}
        <div className="bg-[#151722]/55 backdrop-blur-2xl rounded-3xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] border border-white/[0.08] overflow-hidden flex flex-col md:flex-row">
          
          {/* Left Pane - Register form */}
          <div className="flex-1 p-8 md:p-12 flex flex-col justify-center">
            <div className="mb-6">
              <h2 className="text-3xl font-extrabold text-white mb-2 tracking-tight">Create an account</h2>
              <p className="text-gray-400 text-sm">Join the Syncora conversation today</p>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-5 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm text-center font-medium shadow-sm"
              >
                {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-2">
                  Username <span className="text-rose-500">*</span>
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <User className="h-4.5 w-4.5 text-gray-500 group-focus-within:text-indigo-400 transition-colors" />
                  </div>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="block w-full pl-12 pr-4 py-3 bg-[#090b10]/80 border border-white/10 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/80 transition-all duration-200 text-sm"
                    placeholder="cooluser"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-2">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail className="h-4.5 w-4.5 text-gray-500 group-focus-within:text-indigo-400 transition-colors" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full pl-12 pr-4 py-3 bg-[#090b10]/80 border border-white/10 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/80 transition-all duration-200 text-sm"
                    placeholder="name@domain.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-2">
                  Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock className="h-4.5 w-4.5 text-gray-500 group-focus-within:text-indigo-400 transition-colors" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="block w-full pl-12 pr-4 py-3 bg-[#090b10]/80 border border-white/10 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/80 transition-all duration-200 text-sm"
                    placeholder="••••••••"
                    minLength={6}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center items-center py-3.5 px-4 border border-transparent rounded-2xl shadow-xl text-base font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#151722] focus:ring-indigo-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 mt-4 cursor-pointer active:translate-y-0 shadow-indigo-600/10 hover:shadow-indigo-500/20"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Create Account'
                )}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-gray-400">
              Already have an account?{' '}
              <Link to="/login" className="font-bold text-indigo-400 hover:text-indigo-300 hover:underline transition-all">
                Sign In
              </Link>
            </p>
          </div>

          {/* Right Pane - Syncora Feature List Showcase */}
          <div className="hidden md:flex w-[350px] bg-[#0c0d15]/85 p-10 flex-col items-center justify-center border-l border-white/[0.05] relative overflow-hidden">
            <div className="absolute w-[200px] h-[200px] rounded-full bg-indigo-500/5 blur-[50px] pointer-events-none" />
            
            <SpaceConstellation />
            
            <div className="mt-8 space-y-4 w-full relative z-10">
              <h3 className="text-white text-lg font-bold text-center mb-4">A new way to connect</h3>
              
              <div className="flex items-start space-x-3">
                <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 mt-0.5 shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold">Custom Servers</h4>
                  <p className="text-gray-400 text-[11px] leading-normal">Organize conversations with nested text channels & roles.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 mt-0.5 shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold">Real-Time Sync</h4>
                  <p className="text-gray-400 text-[11px] leading-normal">Fast communication with instant reactions and edits.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400 mt-0.5 shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold">Advanced Roles</h4>
                  <p className="text-gray-400 text-[11px] leading-normal">Full permission control for server owners and moderators.</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </motion.div>
    </div>
  );
};

export default Register;
