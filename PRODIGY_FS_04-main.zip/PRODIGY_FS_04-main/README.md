# 🌌 Syncora

Syncora is a premium real-time collaboration and chat application built with an immersive cosmic deep space aesthetic. Featuring glassmorphism sidebars, custom orbital branding, twinkling backgrounds, and rich messaging interactions, it provides a Discord-like server and DM workspace.

![Syncora UI Concept](https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=800&q=80)

## ✨ Features

- **🛸 Cosmic Visual Experience:** Twinkling SVG space backgrounds, glowing blurred nebulae, and animated custom logos.
- **🛡️ Secure Login Options:** Glassmorphic dual-pane login container with a simulated glowing QR Code portal.
- **💬 Channels & Servers:** Create custom servers, organize discussion topics in nested text channels, and manage users.
- **👥 Friends & Direct Messages:** Add friends, track online statuses, and start instant DMs.
- **🔥 Rich Interactions:** Support for message emoji reactions and threaded replies.
- **🔍 Global Search:** Search across servers, channels, and conversation histories from a slide-out drawer.
- **⚡ Real-Time Sync:** Instant low-latency messaging powered by Socket.io.

## 🛠️ Technology Stack

- **Frontend:** React, Tailwind CSS v4, Framer Motion, Lucide Icons, Vite
- **Backend:** Node.js, Express, Socket.io, MongoDB, Mongoose, JWT (JSON Web Tokens), Bcrypt, Multer

---

## 🚀 Local Setup

### Prerequisites
- [Node.js](https://nodejs.org/) (v16+)
- [MongoDB](https://www.mongodb.com/try/download/community) (running locally on default port 27017 or a cloud database URI)

### 1. Clone the repository
```bash
git clone <your-repository-url>
cd syncora
```

### 2. Configure Backend
Create a `.env` file inside the `backend` directory:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/real_time_chat
JWT_SECRET=your_super_secret_jwt_key
```

Install backend dependencies and start the development server:
```bash
cd backend
npm install
npm run dev
```

### 3. Configure Frontend
Install frontend dependencies and start the Vite dev server:
```bash
cd ../frontend
npm install
npm run dev
```

Open your browser and navigate to **http://localhost:5173** to access the app!

---

## 📜 License
Distributed under the MIT License.
