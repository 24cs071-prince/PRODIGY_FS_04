const Server = require('../models/Server');

exports.requirePermission = (permissionFlag) => {
  return async (req, res, next) => {
    try {
      const { serverId } = req.params;
      if (!serverId) return res.status(400).json({ message: 'Server ID required for permission check' });

      const server = await Server.findById(serverId);
      if (!server) return res.status(404).json({ message: 'Server not found' });

      // Owner has all permissions implicitly
      if (server.owner.toString() === req.user.id) {
        return next();
      }

      // Check if user has roles with the permission
      if (server.memberRoles && server.memberRoles.has(req.user.id)) {
        const userRoleIds = server.memberRoles.get(req.user.id);
        
        for (const roleId of userRoleIds) {
          const role = server.roles.id(roleId);
          if (role && role.permissions && role.permissions[permissionFlag]) {
            return next();
          }
        }
      }

      return res.status(403).json({ message: `Forbidden: Requires ${permissionFlag} permission` });
    } catch (error) {
      res.status(500).json({ message: 'Permission check error', error: error.message });
    }
  };
};
