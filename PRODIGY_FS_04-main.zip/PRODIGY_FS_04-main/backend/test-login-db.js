const mongoose = require('mongoose');
const User = require('./models/User');
const dotenv = require('dotenv');

dotenv.config();

async function test() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB.');

    const email = 'cool12@cool.com';
    const user = await User.findOne({ email });
    if (!user) {
      console.log('User not found in DB!');
      return;
    }

    console.log('Found User in DB:', {
      _id: user._id,
      username: user.username,
      email: user.email,
      hasPassword: !!user.password,
      passwordHash: user.password
    });

    console.log('Testing password verification with "cool12"...');
    try {
      const isMatch = await user.comparePassword('cool12');
      console.log('Password match result ("cool12"):', isMatch);
    } catch (bcryptErr) {
      console.error('Bcrypt comparison failed:', bcryptErr);
    }

    console.log('Simulating user.save()...');
    user.status = 'online';
    await user.save();
    console.log('User saved successfully.');

  } catch (err) {
    console.error('DB Test Error:', err);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected.');
  }
}

test();
