const bcrypt = require('bcrypt');

async function run() {
  try {
    console.log('Testing bcrypt...');
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash('password123', salt);
    console.log('Hash generated successfully:', hash);
    const isMatch = await bcrypt.compare('password123', hash);
    console.log('Comparison matches:', isMatch);
  } catch (err) {
    console.error('Bcrypt Error:', err);
  }
}

run();
