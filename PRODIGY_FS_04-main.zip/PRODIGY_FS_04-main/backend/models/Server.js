const mongoose = require('mongoose');

const roleSchema = new mongoose.Schema({
  name: { type: String, required: true },
  color: { type: String, default: '#ffffff' },
  permissions: {
    MANAGE_SERVER: { type: Boolean, default: false },
    MANAGE_CHANNELS: { type: Boolean, default: false },
    MANAGE_ROLES: { type: Boolean, default: false },
    KICK_MEMBERS: { type: Boolean, default: false }
  }
});

const serverSchema = new mongoose.Schema({
  name: { type: String, required: true },
  icon: { type: String, default: '' },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  inviteCode: { type: String, unique: true },
  roles: [roleSchema],
  memberRoles: {
    type: Map,
    of: [{ type: mongoose.Schema.Types.ObjectId }]
  }
}, { timestamps: true });

module.exports = mongoose.model('Server', serverSchema);
