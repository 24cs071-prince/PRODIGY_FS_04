const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { requirePermission } = require('../middleware/permissionMiddleware');
const { createServer, getServers, joinServer, getChannels, createChannel, createRole, assignRole, kickMember } = require('../controllers/serverController');

router.post('/', protect, createServer);
router.get('/', protect, getServers);
router.post('/join', protect, joinServer);
router.get('/:serverId/channels', protect, getChannels);
router.post('/:serverId/channels', protect, requirePermission('MANAGE_CHANNELS'), createChannel);

// RBAC Routes
router.post('/:serverId/roles', protect, requirePermission('MANAGE_ROLES'), createRole);
router.post('/:serverId/members/:userId/roles', protect, requirePermission('MANAGE_ROLES'), assignRole);
router.delete('/:serverId/members/:userId', protect, requirePermission('KICK_MEMBERS'), kickMember);

module.exports = router;
