const express = require('express');
const router = express.Router();
const { getUsers, getConversations, getMessages, sendMessage, deleteMessage, editMessage, toggleReaction, searchMessages } = require('../controllers/chatController');
const { protect } = require('../middleware/authMiddleware');

router.get('/users', protect, getUsers);
router.get('/conversations', protect, getConversations);
router.get('/search', protect, searchMessages);
router.get('/messages/:conversationId', protect, getMessages);
router.post('/messages', protect, sendMessage);
router.delete('/messages/:messageId', protect, deleteMessage);
router.put('/messages/:messageId', protect, editMessage);
router.post('/messages/:messageId/react', protect, toggleReaction);

module.exports = router;
