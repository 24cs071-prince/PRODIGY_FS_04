const express = require('express');
const router = express.Router();
const { getRooms, createRoom, joinRoom, leaveRoom, getRoomMessages, sendRoomMessage } = require('../controllers/roomController');
const { protect } = require('../middleware/authMiddleware');

router.route('/')
  .get(protect, getRooms)
  .post(protect, createRoom);

router.post('/:roomId/join', protect, joinRoom);
router.post('/:roomId/leave', protect, leaveRoom);

router.route('/:roomId/messages')
  .get(protect, getRoomMessages)
  .post(protect, sendRoomMessage);

module.exports = router;
