const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { sendRequest, acceptRequest, rejectRequest, getFriends, getPendingRequests, searchUsers } = require('../controllers/friendController');

router.post('/request', protect, sendRequest);
router.post('/request/:requestId/accept', protect, acceptRequest);
router.post('/request/:requestId/reject', protect, rejectRequest);
router.get('/', protect, getFriends);
router.get('/requests', protect, getPendingRequests);
router.get('/search', protect, searchUsers);

module.exports = router;
