const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { getMessages, sendMessage } = require('../controllers/channelController');

router.get('/:channelId/messages', protect, getMessages);
router.post('/:channelId/messages', protect, sendMessage);

module.exports = router;
