const mongoose = require('mongoose');
const User = require('./models/User');
const dotenv = require('dotenv');

dotenv.config();

async function list() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB.');

    const users = await User.find({});
    console.log('Registered Users in DB:');
    users.forEach(u => {
      console.log(`- Username: ${u.username}, Email: ${u.email}, Created: ${u.createdAt}`);
    });

  } catch (err) {
    console.error('List Error:', err);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected.');
  }
}

list();
