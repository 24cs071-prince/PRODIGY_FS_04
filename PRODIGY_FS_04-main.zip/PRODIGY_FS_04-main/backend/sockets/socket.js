const User = require('../models/User');

module.exports = (io) => {
  const onlineUsers = new Map(); // Map userId -> socketId

  io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // Register user when they log in
    socket.on('register_user', async (userId) => {
      onlineUsers.set(userId, socket.id);
      await User.findByIdAndUpdate(userId, { status: 'online' });
      io.emit('user_status_change', { userId, status: 'online' });
    });

    // Join a specific conversation room
    socket.on('join_chat', (conversationId) => {
      socket.join(conversationId);
    });

    // Handle typing indicator
    socket.on('typing', ({ conversationId, userId }) => {
      socket.to(conversationId).emit('typing', { conversationId, userId });
    });

    socket.on('stop_typing', ({ conversationId, userId }) => {
      socket.to(conversationId).emit('stop_typing', { conversationId, userId });
    });

    // Handle incoming messages
    socket.on('send_message', (message) => {
      socket.to(message.conversationId || message.roomId).emit('receive_message', message);
    });

    // Handle deleting messages
    socket.on('delete_message', ({ messageId, roomId }) => {
      socket.to(roomId).emit('message_deleted', messageId);
    });

    // Handle editing messages
    socket.on('edit_message', (updatedMessage) => {
      socket.to(updatedMessage.conversationId || updatedMessage.roomId).emit('message_edited', updatedMessage);
    });

    // Handle message reactions
    socket.on('toggle_reaction', ({ messageId, roomId, updatedMessage }) => {
      socket.to(roomId).emit('reaction_updated', { messageId, updatedMessage });
    });

    socket.on('disconnect', async () => {
      console.log(`User disconnected: ${socket.id}`);
      let disconnectedUserId = null;
      for (let [userId, socketId] of onlineUsers.entries()) {
        if (socketId === socket.id) {
          disconnectedUserId = userId;
          onlineUsers.delete(userId);
          break;
        }
      }

      if (disconnectedUserId) {
        await User.findByIdAndUpdate(disconnectedUserId, { 
          status: 'offline', 
          lastSeen: new Date() 
        });
        io.emit('user_status_change', { 
          userId: disconnectedUserId, 
          status: 'offline', 
          lastSeen: new Date() 
        });
      }
    });
  });
};
