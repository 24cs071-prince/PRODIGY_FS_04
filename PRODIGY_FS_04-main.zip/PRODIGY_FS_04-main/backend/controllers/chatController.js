const Conversation = require('../models/Conversation');
const Message = require('../models/Message');
const User = require('../models/User');
const Channel = require('../models/Channel');
const Server = require('../models/Server');

exports.getUsers = async (req, res) => {
  try {
    const users = await User.find({ _id: { $ne: req.user.id } }).select('-password');
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching users', error: error.message });
  }
};

exports.getConversations = async (req, res) => {
  try {
    const conversations = await Conversation.find({ participants: req.user.id })
      .populate('participants', 'username profilePic status lastSeen email')
      .sort({ updatedAt: -1 });
    res.status(200).json(conversations);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching conversations', error: error.message });
  }
};

exports.getMessages = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const messages = await Message.find({ conversationId })
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } })
      .sort({ createdAt: 1 });
    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching messages', error: error.message });
  }
};

exports.sendMessage = async (req, res) => {
  try {
    const { receiverId, text, type, fileUrl, replyTo } = req.body;
    const senderId = req.user.id;

    // Find or create conversation
    let conversation = await Conversation.findOne({
      participants: { $all: [senderId, receiverId] }
    });

    if (!conversation) {
      conversation = await Conversation.create({
        participants: [senderId, receiverId]
      });
    }

    const newMessage = await Message.create({
      conversationId: conversation._id,
      sender: senderId,
      text,
      type,
      fileUrl,
      replyTo: replyTo || undefined
    });

    // Update last message in conversation
    conversation.lastMessage = {
      text: type === 'text' ? text : 'Shared a file',
      sender: senderId,
      seen: false
    };
    await conversation.save();

    const populated = await Message.findById(newMessage._id)
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } });

    res.status(201).json({ message: populated, conversationId: conversation._id });
  } catch (error) {
    res.status(500).json({ message: 'Error sending message', error: error.message });
  }
};

exports.deleteMessage = async (req, res) => {
  try {
    const { messageId } = req.params;
    const message = await Message.findById(messageId);
    
    if (!message) {
      return res.status(404).json({ message: 'Message not found' });
    }

    if (message.sender.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to delete this message' });
    }

    await Message.findByIdAndDelete(messageId);
    res.status(200).json({ message: 'Message deleted successfully', messageId });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting message', error: error.message });
  }
};

exports.editMessage = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { text } = req.body;
    
    const message = await Message.findById(messageId);
    
    if (!message) {
      return res.status(404).json({ message: 'Message not found' });
    }

    if (message.sender.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to edit this message' });
    }

    if (message.type !== 'text') {
      return res.status(400).json({ message: 'Can only edit text messages' });
    }

    message.text = text;
    message.isEdited = true;
    await message.save();

    const populated = await Message.findById(messageId)
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } });

    res.status(200).json({ message: 'Message edited successfully', updatedMessage: populated });
  } catch (error) {
    res.status(500).json({ message: 'Error editing message', error: error.message });
  }
};

exports.toggleReaction = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { emoji } = req.body;
    const userId = req.user.id;

    if (!emoji) return res.status(400).json({ message: 'Emoji is required' });

    const message = await Message.findById(messageId);
    if (!message) return res.status(404).json({ message: 'Message not found' });

    const reactionIndex = message.reactions.findIndex(r => r.emoji === emoji);

    if (reactionIndex > -1) {
      const userIndex = message.reactions[reactionIndex].users.indexOf(userId);
      if (userIndex > -1) {
        message.reactions[reactionIndex].users.splice(userIndex, 1);
        if (message.reactions[reactionIndex].users.length === 0) {
          message.reactions.splice(reactionIndex, 1);
        }
      } else {
        message.reactions[reactionIndex].users.push(userId);
      }
    } else {
      message.reactions.push({ emoji, users: [userId] });
    }

    await message.save();

    const updatedMessage = await Message.findById(messageId)
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } });

    res.status(200).json(updatedMessage);
  } catch (error) {
    res.status(500).json({ message: 'Error toggling reaction', error: error.message });
  }
};

exports.searchMessages = async (req, res) => {
  try {
    const { q, serverId, channelId, conversationId } = req.query;
    if (!q) {
      return res.status(400).json({ message: 'Search query is required' });
    }

    const queryConditions = {
      text: { $regex: q, $options: 'i' }
    };

    if (channelId) {
      const channel = await Channel.findById(channelId);
      if (!channel) return res.status(404).json({ message: 'Channel not found' });
      const server = await Server.findOne({ _id: channel.server, members: req.user.id });
      if (!server) return res.status(403).json({ message: 'Not authorized' });
      queryConditions.roomId = channelId;
    } else if (conversationId) {
      const conv = await Conversation.findOne({ _id: conversationId, participants: req.user.id });
      if (!conv) return res.status(403).json({ message: 'Not authorized' });
      queryConditions.conversationId = conversationId;
    } else if (serverId) {
      const server = await Server.findOne({ _id: serverId, members: req.user.id });
      if (!server) return res.status(403).json({ message: 'Not authorized' });
      const channels = await Channel.find({ server: serverId });
      const channelIds = channels.map(c => c._id);
      queryConditions.roomId = { $in: channelIds };
    } else {
      const conversations = await Conversation.find({ participants: req.user.id });
      const convIds = conversations.map(c => c._id);
      
      const servers = await Server.find({ members: req.user.id });
      const serverIds = servers.map(s => s._id);
      const channels = await Channel.find({ server: { $in: serverIds } });
      const channelIds = channels.map(c => c._id);

      queryConditions.$or = [
        { conversationId: { $in: convIds } },
        { roomId: { $in: channelIds } }
      ];
    }

    const messages = await Message.find(queryConditions)
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } })
      .sort({ createdAt: -1 })
      .limit(50);

    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ message: 'Search failed', error: error.message });
  }
};
