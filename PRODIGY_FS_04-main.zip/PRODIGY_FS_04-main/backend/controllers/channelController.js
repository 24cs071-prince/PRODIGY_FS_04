const Message = require('../models/Message');
const Channel = require('../models/Channel');
const Server = require('../models/Server');

exports.getMessages = async (req, res) => {
  try {
    const { channelId } = req.params;
    
    // Optional: verify user is in the server that owns this channel
    const channel = await Channel.findById(channelId);
    if (!channel) return res.status(404).json({ message: 'Channel not found' });
    
    const server = await Server.findOne({ _id: channel.server, members: req.user.id });
    if (!server) return res.status(403).json({ message: 'Not a member of this server' });

    const messages = await Message.find({ roomId: channelId })
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } });
    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.sendMessage = async (req, res) => {
  try {
    const { channelId } = req.params;
    const { text, type, fileUrl, replyTo } = req.body;

    const channel = await Channel.findById(channelId);
    if (!channel) return res.status(404).json({ message: 'Channel not found' });

    const server = await Server.findOne({ _id: channel.server, members: req.user.id });
    if (!server) return res.status(403).json({ message: 'Not a member of this server' });

    const message = await Message.create({
      roomId: channelId, // reusing roomId field to mean channelId
      sender: req.user.id,
      text,
      type: type || 'text',
      fileUrl,
      replyTo: replyTo || undefined
    });

    const populatedMessage = await Message.findById(message._id)
      .populate('sender', 'username profilePic')
      .populate({ path: 'replyTo', populate: { path: 'sender', select: 'username' } });
    res.status(201).json(populatedMessage);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
