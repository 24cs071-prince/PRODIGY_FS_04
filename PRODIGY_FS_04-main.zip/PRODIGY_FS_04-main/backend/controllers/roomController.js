const ChatRoom = require('../models/ChatRoom');
const Message = require('../models/Message');

exports.getRooms = async (req, res) => {
  try {
    const rooms = await ChatRoom.find()
      .populate('createdBy', 'username')
      .populate('participants', 'username profilePic');
    res.status(200).json(rooms);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching rooms', error: error.message });
  }
};

exports.createRoom = async (req, res) => {
  try {
    const { name, description } = req.body;
    
    const existingRoom = await ChatRoom.findOne({ name });
    if (existingRoom) {
      return res.status(400).json({ message: 'Room name already exists' });
    }

    const room = await ChatRoom.create({
      name,
      description,
      createdBy: req.user.id,
      participants: [req.user.id]
    });

    res.status(201).json(room);
  } catch (error) {
    res.status(500).json({ message: 'Error creating room', error: error.message });
  }
};

exports.joinRoom = async (req, res) => {
  try {
    const { roomId } = req.params;
    const room = await ChatRoom.findById(roomId);
    
    if (!room) {
      return res.status(404).json({ message: 'Room not found' });
    }

    if (!room.participants.includes(req.user.id)) {
      room.participants.push(req.user.id);
      await room.save();
    }

    res.status(200).json(room);
  } catch (error) {
    res.status(500).json({ message: 'Error joining room', error: error.message });
  }
};

exports.leaveRoom = async (req, res) => {
  try {
    const { roomId } = req.params;
    const room = await ChatRoom.findById(roomId);

    if (!room) {
      return res.status(404).json({ message: 'Room not found' });
    }

    room.participants = room.participants.filter(p => p.toString() !== req.user.id);
    await room.save();

    res.status(200).json({ message: 'Left room successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error leaving room', error: error.message });
  }
};

exports.getRoomMessages = async (req, res) => {
  try {
    const { roomId } = req.params;
    const messages = await Message.find({ roomId })
      .populate('sender', 'username profilePic')
      .sort({ createdAt: 1 });
    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching room messages', error: error.message });
  }
};

exports.sendRoomMessage = async (req, res) => {
  try {
    const { roomId } = req.params;
    const { text, type, fileUrl } = req.body;
    
    const newMessage = await Message.create({
      roomId,
      sender: req.user.id,
      text,
      type,
      fileUrl
    });

    const populatedMessage = await newMessage.populate('sender', 'username profilePic');

    res.status(201).json(populatedMessage);
  } catch (error) {
    res.status(500).json({ message: 'Error sending room message', error: error.message });
  }
};
