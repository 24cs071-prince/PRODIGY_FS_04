const Server = require('../models/Server');
const Channel = require('../models/Channel');
const crypto = require('crypto');

exports.createServer = async (req, res) => {
  try {
    const { name, icon } = req.body;
    
    // Generate unique invite code
    const inviteCode = crypto.randomBytes(4).toString('hex');

    const server = await Server.create({
      name,
      icon,
      owner: req.user.id,
      members: [req.user.id],
      inviteCode
    });

    // Create default general channel
    await Channel.create({
      name: 'general',
      type: 'text',
      server: server._id
    });

    res.status(201).json(server);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getServers = async (req, res) => {
  try {
    const servers = await Server.find({ members: req.user.id }).populate('owner', 'username');
    res.status(200).json(servers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.joinServer = async (req, res) => {
  try {
    const { inviteCode } = req.body;
    const server = await Server.findOne({ inviteCode });

    if (!server) return res.status(404).json({ message: 'Invalid invite code' });
    if (server.members.includes(req.user.id)) return res.status(400).json({ message: 'Already a member' });

    server.members.push(req.user.id);
    await server.save();

    res.status(200).json(server);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getChannels = async (req, res) => {
  try {
    const { serverId } = req.params;
    
    // Verify membership
    const server = await Server.findOne({ _id: serverId, members: req.user.id });
    if (!server) return res.status(403).json({ message: 'Not a member of this server' });

    const channels = await Channel.find({ server: serverId });
    res.status(200).json(channels);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createChannel = async (req, res) => {
  try {
    const { serverId } = req.params;
    const { name, type } = req.body;

    const server = await Server.findOne({ _id: serverId, members: req.user.id });
    if (!server) return res.status(403).json({ message: 'Not a member' });

    // For now any member can create channels. Phase 9 (RBAC) will fix this.
    const channel = await Channel.create({
      name,
      type: type || 'text',
      server: serverId
    });

    res.status(201).json(channel);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// RBAC APIs
exports.createRole = async (req, res) => {
  try {
    const { serverId } = req.params;
    const { name, color, permissions } = req.body;
    
    const server = await Server.findById(serverId);
    if (!server) return res.status(404).json({ message: 'Server not found' });
    
    // Quick owner check (Proper middleware later)
    if (server.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Only owner can create roles for now' });

    server.roles.push({ name, color, permissions });
    await server.save();
    res.status(201).json(server);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.assignRole = async (req, res) => {
  try {
    const { serverId, userId } = req.params;
    const { roleId } = req.body;

    const server = await Server.findById(serverId);
    if (server.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Only owner can assign roles' });
    
    if (!server.memberRoles) server.memberRoles = new Map();
    
    let userRoles = server.memberRoles.get(userId) || [];
    if (!userRoles.includes(roleId)) {
      userRoles.push(roleId);
      server.memberRoles.set(userId, userRoles);
      await server.save();
    }
    
    res.status(200).json(server);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.kickMember = async (req, res) => {
  try {
    const { serverId, userId } = req.params;
    const server = await Server.findById(serverId);
    
    if (server.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Only owner can kick members' });
    if (server.owner.toString() === userId) return res.status(400).json({ message: 'Cannot kick the owner' });

    server.members = server.members.filter(m => m.toString() !== userId);
    if (server.memberRoles && server.memberRoles.has(userId)) {
      server.memberRoles.delete(userId);
    }
    
    await server.save();
    res.status(200).json(server);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
