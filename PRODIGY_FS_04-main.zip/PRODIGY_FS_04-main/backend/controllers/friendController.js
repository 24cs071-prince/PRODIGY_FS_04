const User = require('../models/User');

exports.sendRequest = async (req, res) => {
  try {
    const { username } = req.body;
    const targetUser = await User.findOne({ username });

    if (!targetUser) return res.status(404).json({ message: 'User not found' });
    if (targetUser._id.toString() === req.user.id) return res.status(400).json({ message: 'Cannot send request to yourself' });

    const user = await User.findById(req.user.id);
    
    if (user.friends.includes(targetUser._id)) return res.status(400).json({ message: 'Already friends' });
    if (user.friendRequestsSent.includes(targetUser._id)) return res.status(400).json({ message: 'Request already sent' });

    user.friendRequestsSent.push(targetUser._id);
    targetUser.friendRequestsReceived.push(user._id);

    await user.save();
    await targetUser.save();

    res.status(200).json({ message: 'Friend request sent successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.acceptRequest = async (req, res) => {
  try {
    const { requestId } = req.params;
    const user = await User.findById(req.user.id);
    const targetUser = await User.findById(requestId);

    if (!user.friendRequestsReceived.includes(requestId)) return res.status(400).json({ message: 'No request found' });

    user.friendRequestsReceived = user.friendRequestsReceived.filter(id => id.toString() !== requestId);
    targetUser.friendRequestsSent = targetUser.friendRequestsSent.filter(id => id.toString() !== req.user.id);

    user.friends.push(requestId);
    targetUser.friends.push(user._id);

    await user.save();
    await targetUser.save();

    res.status(200).json({ message: 'Friend request accepted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.rejectRequest = async (req, res) => {
  try {
    const { requestId } = req.params;
    const user = await User.findById(req.user.id);
    const targetUser = await User.findById(requestId);

    user.friendRequestsReceived = user.friendRequestsReceived.filter(id => id.toString() !== requestId);
    if(targetUser) {
        targetUser.friendRequestsSent = targetUser.friendRequestsSent.filter(id => id.toString() !== req.user.id);
        await targetUser.save();
    }

    await user.save();
    res.status(200).json({ message: 'Friend request rejected' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getFriends = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate('friends', 'username profilePic status lastSeen bio');
    res.status(200).json(user.friends);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getPendingRequests = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate('friendRequestsReceived', 'username profilePic');
    res.status(200).json(user.friendRequestsReceived);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.searchUsers = async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.status(200).json([]);
    
    const users = await User.find({
      username: { $regex: q, $options: 'i' },
      _id: { $ne: req.user.id }
    }).select('username profilePic bio friends friendRequestsReceived friendRequestsSent');
    
    // We can return the users, the frontend can check if already friends based on its own state,
    // or we can format it here. We'll just return the raw users for simplicity.
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
